package action;

public interface Action {
	
	public void executer();

}
