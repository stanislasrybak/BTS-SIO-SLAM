package action;

public class ActionErreur implements Action {

	@Override
	public void executer() {
		
		System.out.println("ERREUR DE SAISIE");

	}

}
