package action;

public class ActionFin implements Action {

	@Override
	public void executer() {
		
		System.out.println("FIN DE L'APPLICATION");

	}

}
