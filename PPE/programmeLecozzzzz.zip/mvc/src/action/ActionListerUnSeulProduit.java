package action;

import vue.Code;
import dao.GerantDeProduit;
import dao.GerantDeProduitImpl;

public class ActionListerUnSeulProduit implements Action {

	@Override
	public void executer() {
		
		GerantDeProduit gerant = new GerantDeProduitImpl();
		System.out.println(gerant.lireUn(new Code().afficher1()));

	}

}
