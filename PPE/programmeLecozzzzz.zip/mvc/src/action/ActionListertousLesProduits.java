package action;

import modele.Produit;
import dao.GerantDeProduit;
import dao.GerantDeProduitImpl;

public class ActionListertousLesProduits implements Action {

	@Override
	public void executer() {
		
		GerantDeProduit gerant = new GerantDeProduitImpl();
		for(Produit ref: gerant.lireTous())
			System.out.println(ref);

	}

}
