package application;

import controleur.Controleur;

public class Application {

	public static void main(String[] args) {
		
		Controleur ctrl = new Controleur();
		ctrl.controler();

	}

}
