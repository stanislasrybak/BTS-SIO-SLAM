package controleur;

import vue.Menu;

public class Controleur {

	private Menu menu = new Menu();

	public void controler() {
		String choix = "";
		while (!choix.equals("3")) {
			choix = menu.afficher();
			FabriqueAction fabrique = new FabriqueAction();
			fabrique.fabriquer(choix).executer();
		}
	}

}
