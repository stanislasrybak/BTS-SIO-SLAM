package controleur;

import action.Action;
import action.ActionErreur;
import action.ActionFin;
import action.ActionListerUnSeulProduit;
import action.ActionListertousLesProduits;

public class FabriqueAction {

	public Action fabriquer(String argument) {

		if (argument.equals("1"))
			return new ActionListertousLesProduits();
		else if (argument.equals("2"))
			return new ActionListerUnSeulProduit();
		else if (argument.equals("3"))
			return new ActionFin();
		else
			return new ActionErreur();

	}

}
