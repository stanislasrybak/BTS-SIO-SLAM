package dao;

import java.util.List;

import modele.Produit;

public interface GerantDeProduit {
	
	public List<Produit> lireTous();
	public Produit lireUn(String code);

}
