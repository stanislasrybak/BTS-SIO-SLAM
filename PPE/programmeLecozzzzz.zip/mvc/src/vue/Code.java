package vue;

import java.util.Scanner;

public class Code {
	
	public String afficher1() {
		System.out.println("Code :");
		Scanner entree = new Scanner(System.in);
		String code = entree.nextLine();
		return code;
	}

}
