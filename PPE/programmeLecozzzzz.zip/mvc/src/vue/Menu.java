package vue;

import java.util.Scanner;

public class Menu {

	public String afficher() {
		String choix = "ERREUR";
		System.out.println("1 - Lister tous les produits");
		System.out.println("2 - Lister un seul produit");
		System.out.println("3 - Fin de l'application");
		System.out.println("Entrez votre choix : ");
		Scanner entree = new Scanner(System.in);
		choix = entree.nextLine();
		return choix;
	}

}
